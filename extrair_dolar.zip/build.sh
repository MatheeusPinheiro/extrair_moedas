#!/bin/bash

zip -r "extrair_dolar.zip" * -x "extrair_dolar.zip"